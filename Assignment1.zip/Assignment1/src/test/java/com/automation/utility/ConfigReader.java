package com.automation.utility;

import java.io.FileReader;
import java.util.Properties;

public class ConfigReader {
	public static String readProjectConfiguration(String keyName)
	{
	String value =null;
	try
	{
	FileReader file=new FileReader("ConfigFiles/ProjectConfiguration.properties");
	Properties  readproperty =new Properties();
	readproperty.load(file);
	
	return readproperty.getProperty(keyName).trim();
	
	}
	catch(Exception ex)
	{
	ex.printStackTrace();
	throw (new RuntimeException("*****ERROR*******---key with name"+ keyName + "does not exists"));
	}
	}
	public static String readElementLocators(String keyName)
	{
	String value =null;
	try
	{
	FileReader file=new FileReader("ElementLocators/Locators.properties");
	Properties  readproperty =new Properties();
	readproperty.load(file);
	
	return readproperty.getProperty(keyName).trim();
	
	}
	catch(Exception ex)
	{
	ex.printStackTrace();
	throw (new RuntimeException("*****ERROR*******---locator with name"+ keyName + "does not exists"));
	}
	}
}



