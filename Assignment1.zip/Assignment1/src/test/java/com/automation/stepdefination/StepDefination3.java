package com.automation.stepdefination;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.api.java.en.*;
public class StepDefination3 {

	WebDriver driver = null;
	 String xpath;
	 
   
	 
	 @Given("^User is on download demo page$")
	 public void user_is_on_download_demo_page() throws Throwable {
		 System.setProperty("webdriver.chrome.driver","./driver/chromedriver.exe" );
		 driver = new ChromeDriver();
		 driver.get("https://www.seleniumeasy.com/test/bootstrap-download-progress-demo.html");
	      driver.manage().window().maximize();
	 
	 }

	 @When("^User clicks on download button$")
	 public void user_clicks_on_download_button() throws Throwable {

			driver.findElement(By.xpath("//*[@id=\"cricle-btn\"]")).click();

	   
	 }

	 @Then("^message should change$")
	 public void message_should_change() throws Throwable {
		

	 }


}
