package com.automation.stepdefination;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.api.java.en.*;

public class StepDefination4  {
	
	WebDriver driver = null;	
	@Given("^User is on dual list box page$")
	public void user_is_on_dual_list_box_page() throws Throwable {
		 System.setProperty("webdriver.chrome.driver","./driver/chromedriver.exe" );
		 driver = new ChromeDriver();
		 driver.get("https://www.seleniumeasy.com/test/bootstrap-dual-list-box-demo.html");
	      driver.manage().window().maximize();

	}	


	@When("^User clicks on one row  from left box$")
	public void user_clicks_on_one_row_from_left_box() throws Throwable {
		driver.findElement(By.xpath("/html/body/div[2]/div/div[2]/div/div[1]/div/ul/li[3]")).click();

	}
	 
	

	@When("^User clicks on right arrow button$")
	public void user_clicks_on_right_arrow_button() throws Throwable {
		driver.findElement(By.xpath("/html/body/div[2]/div/div[2]/div/div[2]/button[2]")).click();
	  
	}

	@Then("^Row should shifted to right box$")
	public void row_should_shifted_to_right_box() throws Throwable {
		  
	}

	@When("^User clicks on left arrow button$")
	public void user_clicks_on_left_arrow_button() throws Throwable {
		driver.findElement(By.xpath("/html/body/div[2]/div/div[2]/div/div[2]/button[1]")).click();
	   
	}

	@Then("^Selected row should shifted to left$")
	public void selected_row_should_shifted_to_left() throws Throwable {
	 
	}

	@When("^User clicks on multiple row  from left box$")
	public void user_clicks_on_multiple_row_from_left_box() throws Throwable {
		driver.findElement(By.xpath("/html/body/div[2]/div/div[2]/div/div[1]/div/ul/li[1]")).click();
		driver.findElement(By.xpath("/html/body/div[2]/div/div[2]/div/div[1]/div/ul/li[3]")).click();
		driver.findElement(By.xpath("/html/body/div[2]/div/div[2]/div/div[1]/div/ul/li[2]")).click();

		
	}

	@Then("^Rows should shifted to right box$")
	public void rows_should_shifted_to_right_box() throws Throwable {

	}

	@Then("^Selected rows should shifted to left$")
	public void selected_rows_should_shifted_to_left() throws Throwable {
		
	   
	}

	@When("^User clicks on all rows from left box$")
	public void user_clicks_on_all_rows_from_left_box() throws Throwable {
		driver.findElement(By.xpath("/html/body/div[2]/div/div[2]/div/div[1]/div/ul/li[1]")).click();
		driver.findElement(By.xpath("/html/body/div[2]/div/div[2]/div/div[1]/div/ul/li[2]")).click();
		driver.findElement(By.xpath("/html/body/div[2]/div/div[2]/div/div[1]/div/ul/li[3]")).click();
		driver.findElement(By.xpath("/html/body/div[2]/div/div[2]/div/div[1]/div/ul/li[4]")).click();
		driver.findElement(By.xpath("/html/body/div[2]/div/div[2]/div/div[1]/div/ul/li[5]")).click();

	  
	}
}
