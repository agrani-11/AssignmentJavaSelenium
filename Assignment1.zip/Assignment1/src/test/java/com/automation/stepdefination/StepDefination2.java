package com.automation.stepdefination;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.api.java.en.*;


public class StepDefination2 {
	
	WebDriver driver = null;
	 String xpath;

	
	
	@Given("^User is on table search filter page$")
	public void user_is_on_table_search_filter_page() throws Throwable {
		 System.setProperty("webdriver.chrome.driver","./driver/chromedriver.exe" );
		 driver = new ChromeDriver();
		 driver.get("https://www.seleniumeasy.com/test/table-search-filter-demo.html");
	      driver.manage().window().maximize();

	}

	@When("^User clicks on textbox of task table and enter input$")
	public void user_clicks_on_textbox_of_task_table_and_enter_input() throws Throwable {
		driver.findElement(By.xpath("//*[@id=\"task-table-filter\"]")).click();
	}

	@When("^User Apply filter with Assignee name$")
	public void user_Apply_filter_with_Assignee_name() throws Throwable {
		driver.findElement(By.id("task-table-filter")).sendKeys("Trout");
		
	   
	}
	

	@Then("^List of only assignee filter applied should display$")
	public void list_of_only_assignee_filter_applied_should_display() throws Throwable {

	}

	@When("^User Apply filter on Status$")
	public void user_Apply_filter_on_Status() throws Throwable {
		driver.findElement(By.xpath("//*[@data-filters=\"#task-table\"]")).sendKeys("in progress");
	}

	@Then("^List with only status filter applied should display$")
	public void list_with_only_status_filter_applied_should_display() throws Throwable {

	}
	
	@When("^User aplies filter on tables listed user username$")
	public void user_aplies_filter_on_tables_listed_user_username() throws Throwable {
		driver.findElement(By.xpath("/html/body/div[2]/div/div[2]/div[2]/div/div/div/button")).click();
		driver.findElement(By.xpath("//*[@placeholder=\"Username\"]")).sendKeys("jacobs");
		
	}

	@Then("^list with only applied username should display$")
	public void list_with_only_applied_username_should_display() throws Throwable {
	   
	}



}
