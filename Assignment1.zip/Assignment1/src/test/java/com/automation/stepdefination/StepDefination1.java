package com.automation.stepdefination;




import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import org.openqa.selenium.chrome.ChromeDriver;



import cucumber.api.java.en.*;

public class StepDefination1 {

	
	WebDriver driver = null;
	 String xpath;
	
	

	 // code to open giver url using webdriver
@Given("^User is on bootstrap date picker page$")
public void user_is_on_bootstrap_date_picker_page() throws Throwable {
	 System.setProperty("webdriver.chrome.driver","./driver/chromedriver.exe" );
	 driver = new ChromeDriver();
	 driver.get("https://www.seleniumeasy.com/test/bootstrap-date-picker-demo.html ");
      driver.manage().window().maximize();
   
   
}


//code to open calender 
@When("^User clicks on select date calender icon$")
public void user_clicks_on_select_date_calender_icon() throws Throwable
    {
	driver.findElement(By.xpath("//*[@id=\"sandbox-container1\"]/div/span")).click();
	}

@Then("^Calender should be display$")
public void calender_should_be_display() throws Throwable {
  
}


//code to select future date
@When("^User clicks any future  date$")
public  void user_clicks_any_future_date() throws Throwable {
driver.findElement(By.xpath("//*[@class='disabled day']")).click();
}
 
@Then("^Date should not be select$")
public void date_should_not_be_select() throws Throwable {
	
}


//code to select sunday
@When("^User clicks on  date which is sunday$")
public void user_clicks_on_date_which_is_sunday() throws Throwable {
	driver.findElement(By.xpath("//*[@class='disabled disabled-date day']")).click();
 
}

@Then("^Date should not be display$")
public void date_should_not_be_display() throws Throwable {
  
}

//code to select sunday
@Given("^User is on bootstrap date pickerpage$")
public void user_is_on_bootstrap_date_pickerpage() throws Throwable {
	 System.setProperty("webdriver.chrome.driver","./driver/chromedriver.exe" );
	 driver = new ChromeDriver();
	 driver.get("https://www.seleniumeasy.com/test/bootstrap-date-picker-demo.html ");
      driver.manage().window().maximize();
  
}

@When("^User clicks on date$")
public void user_clicks_on_date() throws Throwable {
	driver.findElement(By.xpath("//*[@class='day']")).click();
	
}

@When("^user clicks on cal icon$")
public void user_clicks_on_cal_icon() throws Throwable {
	driver.findElement(By.xpath("//*[@id=\"sandbox-container1\"]/div/span")).click();

}


@When("^Clicks on clear$")
public void clicks_on_clear() throws Throwable {
	driver.findElement(By.xpath("//*[@class='clear']")).click();
   
}

@Then("^Date should be clear$")
public void date_should_be_clear() throws Throwable {

}


}
