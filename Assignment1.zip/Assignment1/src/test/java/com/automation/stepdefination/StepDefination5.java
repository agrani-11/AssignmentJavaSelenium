package com.automation.stepdefination;




import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import org.openqa.selenium.chrome.ChromeDriver;

import org.openqa.selenium.interactions.Actions;

import cucumber.api.java.en.*;

public class StepDefination5 {
	
	WebDriver driver = null;
	
	@Given("^User is on drag slider page$")
	public void user_is_on_drag_slider_page() throws Throwable {
		System.setProperty("webdriver.chrome.driver","./driver/chromedriver.exe" );
		driver = new ChromeDriver();
		 driver.get("https://www.seleniumeasy.com/test/drag-drop-range-sliders-demo.html ");
	      driver.manage().window().maximize();

	}

	@When("^User drag  first slider to given value$")
	public void user_drag_first_slider_to_given_value() throws Throwable {
	
		WebElement sliderOne = driver.findElement(By.xpath("//*[@class='range']/input"));
        Actions action = new Actions(driver);
        action.clickAndHold(sliderOne);
        action.moveByOffset(26, 0).release().build().perform();
        
	    
	}

	@Then("^First slider value should set to given value$")
	public void first_slider_value_should_set_to_given_value() throws Throwable {
	
    }

	
	
	@When("^User drag  second slider to given value$")
	public void user_drag_second_slider_to_given_value() throws Throwable {
		WebElement sliderTwo = driver.findElement(By.xpath("//*[@id=\"slider2\"]/div/input"));
        Actions action = new Actions(driver);
        action.clickAndHold(sliderTwo);
        action.moveByOffset(25, 0).release().build().perform();
		
	    
	}

	@Then("^Second slider value should set to given value$")
	public void second_slider_value_should_set_to_given_value() throws Throwable {
	    
	}

	
	
	@When("^User drag  third slider to given value$")
	public void user_drag_third_slider_to_given_value() throws Throwable {
		WebElement sliderThree = driver.findElement(By.xpath("//*[@id=\"slider3\"]/div/input"));
        Actions action = new Actions(driver);
        action.clickAndHold(sliderThree);
        action.moveByOffset(25, 0).release().build().perform();
		

	   
	}

	@Then("^Third slider value should set to given value$")
	public void third_slider_value_should_set_to_given_value() throws Throwable {
	    
	}

	
	
	@When("^User drag  fourth slider to given value$")
	public void user_drag_fourth_slider_to_given_value() throws Throwable {
	
	    	WebElement sliderFour= driver.findElement(By.xpath("//*[@id=\"slider4\"]/div/input"));
	        Actions action = new Actions(driver);
	        action.clickAndHold(sliderFour);
	        action.moveByOffset(25, 0).release().build().perform();

	}

	@Then("^Fourth slider value should set to given value$")
	public void fourth_slider_value_should_set_to_given_value() throws Throwable {
	    
	}

	
	
	@When("^User drag  fifth slider to given value$")
	public void user_drag_fifth_slider_to_given_value() throws Throwable {
		WebElement sliderFive = driver.findElement(By.xpath("//*[@id=\"slider5\"]/div/input"));
        Actions action = new Actions(driver);
        action.clickAndHold(sliderFive);
        action.moveByOffset(25, 0).release().build().perform();
	}

	@Then("^Fifth slider value should set to given value$")
	public void fifth_slider_value_should_set_to_given_value() throws Throwable {

       }

	
	
	@When("^User drag  sixth slider to given value$")
	public void user_drag_sixth_slider_to_given_value() throws Throwable {  
		WebElement sliderSix = driver.findElement(By.xpath("//*[@id=\"slider6\"]/div/input"));
        Actions action = new Actions(driver);
        action.clickAndHold(sliderSix);
        action.moveByOffset(25, 0).release().build().perform();
    
	  
	}

	@Then("^Sixth slider value should set to given value$")
	public void sixth_slider_value_should_set_to_given_value() throws Throwable {

	}


}
